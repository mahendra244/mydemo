<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/CommentManager.php');
  $commentdel=CommentManager::getInstance();
  $id = $_GET['id'];
  $sql=$commentdel->deleteComment($id);
  if($sql)
  {
    echo '<a href="index.php">Comment deleted! , For main menu click here!</a>';
  }
  else
  {
      echo "Error ! Please try again";
  }


?>