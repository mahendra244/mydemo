<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/CommentManager.php');
$insertdata=CommentManager::getInstance();

if(isset($_POST['submit']))
{
   
 
    $body = $_POST['comment_body'];
    $newsId = $_POST['news_id'];
   
    $sql=$insertdata->addCommentForNews($body, $newsId);
    if($sql)
    {
       echo '<a href="index.php">Successfully Added! , For main menu click here!</a>';
    }
    else
    {
        echo "Data inserted error !";
    }
}
 ?>

