


<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/NewsManager.php');
require_once(ROOT . '/utils/CommentManager.php');
$newsid=$_GET['id'];
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<script type='text/javascript' src='jquery.pack.js'></script>
<script type='text/javascript'>
$(function(){
    $("a.reply").click(function() {
        var id = $(this).attr("id");
        $("#parent_id").attr("value", id);
        $("#name").focus();
    });
});
</script>
<style type='text/css'>
html, body, div, h1, h2, h3, h4, h5, h6, ul, ol, dl, li, dt, dd, p, blockquote,
pre, form, fieldset, table, th, td { margin: 0; padding: 0; }

body {
font-size: 14px;
line-height:1.3em;
background: url('music.jpg');
height: 100%;
background-size:100% ;
background-position: static;
background-color: purple;
min-height: 100%;
background-repeat: no-repeat;
}
label{
    color: white;
    font-size: 2em;
}

a, a:visited {
outline:none;
color:#7d5f1e;
}

.clear {
clear:both;
}

#wrapper {
    width:480px;
    margin:0px auto;
    padding:15px 0px;
}

.comment {
    padding:5px;
    border:2px solid black;
    border-width: 1px;
    margin-top:15px;
    list-style:none;
    background-color: white;
      opacity: 0.96;
        -moz-border-radius:20px;
  -webkit-border-radius:20px;
  overflow-y: scroll;

}

.aut {
    font-weight:bold;
}

.timestamp {
    font-size:85%;
    float:right;
}

#comment_form {
    margin-top:15px;

}

#comment_form input {
    font-size:1.2em;
    margin:0 0 10px;
    padding:3px;
    display:block;
    width:100%;

}

#comment_body {
    display:block;
    width:100%;
    height:150px;

}

#submit_button {
    text-align:center; 
    clear:both;
}
header{
    color: white;
    text-align: center;
}
</style>
</head>
<body>



<body>

<div id='wrapper'>
    <header><font size="20">Comment</font></header>
    <br>
<ul>

</ul>

    <form id="comment_form" action="commentcrud.php" method='post'>
    <label for="comment_body">Add Comment:</label>
    <textarea name="comment_body" id='comment_body'></textarea>
    <input type="hidden" name="news_id" id="news_id" value="<?php echo $newsid;?>">;
   <br><br>
    <input type="submit" name="submit" value="submit" /> 
</form>
</div>
</body>
</html>
