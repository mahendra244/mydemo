
<!DOCTYPE html>
<html lang="en">
<head>

  <title>Assessment Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/NewsManager.php');
require_once(ROOT . '/utils/CommentManager.php');
?>
<body>

<div class="container">
  <br>
  <br>
<button  onclick="window.location.href = 'newsadd.php' ">create news</button><br>

  <h2>News Details</h2>
  <table class="table">
    <thead>
      <tr>
        <th>Title</th>
        <th>News details</th>
        <th>Commented</th>
        <th>Add Comment</th>
        <th>Action</th>

      </tr>
    </thead>
    <tbody>
<?php
	foreach (NewsManager::getInstance()->listNews() as $news) {
    echo'<td><strong>'. $news->getTitle().'</strong></td>';
	  echo'<td><strong>'. $news->getBody() .'</strong></td>';
    echo '<td>';
	foreach (CommentManager::getInstance()->listComments() as $comment) {
	if ($comment->getNewsId() == $news->getId()) {
			echo $comment->getBody().'&nbsp;&nbsp;|&nbsp;&nbsp;<a  href="delete_comment.php?id='.$comment->getId().'">delete</a>';
      echo "</br>";
		}
	}
  echo '</td>';
  
	echo'<td><a href="commentsadd.php?id='.$news->getId().'">create comment</a></td>';
  echo'<td><a href="delete_process.php?id='.$news->getId().'">Delete news</a></td></tr>';
	}
?>
    </tbody>
  </table>
</div>

</body>
</html>

