<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/NewsManager.php');
$insertdata=NewsManager::getInstance();
if(isset($_POST['submit']))
{
    $title = $_POST['news_title'];
    $body = $_POST['news_body'];
   
    $sql=$insertdata->addNews($title, $body);
    if($sql)
    {
        echo '<a href="index.php">Successfully Created! , For main menu click here!</a>';
    }
    else
    {
        echo "Data inserted error !";
    }
}
 ?>

