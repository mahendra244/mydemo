<?php
define('ROOT', __DIR__);
require_once(ROOT . '/utils/NewsManager.php');
  $newsdel=NewsManager::getInstance();
  $id = $_GET['id'];
  $sql=$newsdel->deleteNews($id);
  if($sql)
  {
    echo '<a href="index.php">News deleted! , For main menu click here!</a>';

  }
  else
  {
      echo "Error ! Please try again";
  }


?>